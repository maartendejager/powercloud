class PowerCloudUIComponent{constructor(t={}){this.options={theme:"default",accessibility:!0,animations:!0,...t},this.element=null,this.shadowRoot=null}create(t=!1){return this.element=this.createElement(),t&&this.element.attachShadow?(this.shadowRoot=this.element.attachShadow({mode:"open"}),this.setupShadowContent()):this.setupContent(),this.attachEvents(),this.applyAccessibility(),this.element}createElement(){throw new Error("createElement must be implemented by subclass")}setupContent(){if(!document.querySelector("#powercloud-component-styles")){const t=document.createElement("style");t.id="powercloud-component-styles",t.textContent=this.getComponentStyles(),document.head.appendChild(t)}}setupShadowContent(){const t=document.createElement("style");t.textContent=this.getComponentStyles(),this.shadowRoot.appendChild(t),this.setupContent()}getComponentStyles(){return PowerCloudUIStyles.getBaseStyles()+this.getCustomStyles()}getCustomStyles(){return""}attachEvents(){}applyAccessibility(){if(!this.options.accessibility||!this.element)return;this.element.querySelectorAll('button, input, select, textarea, [tabindex]:not([tabindex="-1"])').forEach(e=>{!e.getAttribute("role")&&e.tagName==="BUTTON"&&e.setAttribute("role","button")})}destroy(){this.element&&this.element.parentNode&&this.element.parentNode.removeChild(this.element),this.element=null,this.shadowRoot=null}}class PowerCloudUIStyles{static getBaseStyles(){return`
        /* CSS Reset for PowerCloud components */
        .powercloud-component, .powercloud-component * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        /* Design tokens */
        :root {
            --pc-primary-color: #0066cc;
            --pc-secondary-color: #6c757d;
            --pc-success-color: #28a745;
            --pc-error-color: #dc3545;
            --pc-warning-color: #ffc107;
            --pc-info-color: #17a2b8;
            --pc-light-color: #f8f9fa;
            --pc-dark-color: #343a40;
            
            --pc-font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            --pc-font-size-sm: 12px;
            --pc-font-size-md: 14px;
            --pc-font-size-lg: 16px;
            
            --pc-border-radius: 6px;
            --pc-spacing-sm: 8px;
            --pc-spacing-md: 16px;
            --pc-spacing-lg: 24px;
            
            --pc-shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
            --pc-shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
            --pc-shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
            
            --pc-z-index-dropdown: 1000;
            --pc-z-index-modal: 1050;
            --pc-z-index-tooltip: 1100;
            --pc-z-index-extension: 9999;
        }
        
        /* Screen reader only content */
        .powercloud-sr-only {
            position: absolute !important;
            width: 1px !important;
            height: 1px !important;
            padding: 0 !important;
            margin: -1px !important;
            overflow: hidden !important;
            clip: rect(0, 0, 0, 0) !important;
            white-space: nowrap !important;
            border: 0 !important;
        }
        
        /* Focus styles */
        .powercloud-component:focus-visible {
            outline: 2px solid var(--pc-primary-color);
            outline-offset: 2px;
        }
    `}static getComponentStyles(t){const e=this.getBaseStyles();switch(t){case"button":return e+this.getButtonStyles();case"alert":return e+this.getAlertStyles();case"badge":return e+this.getBadgeStyles();default:return e}}static getButtonStyles(){return`
        .powercloud-button {
            font-family: var(--pc-font-family);
            font-size: var(--pc-font-size-md);
            border-radius: var(--pc-border-radius);
            transition: all 0.2s ease-in-out;
            border: none;
            cursor: pointer;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            position: relative;
            overflow: hidden;
        }

        .powercloud-button:focus {
            outline: 2px solid var(--pc-primary-color);
            outline-offset: 2px;
        }

        .powercloud-button:active {
            transform: translateY(1px);
        }

        /* Sizes */
        .powercloud-button--small {
            padding: 6px 12px;
            font-size: var(--pc-font-size-sm);
        }

        .powercloud-button--medium {
            padding: 8px 16px;
            font-size: var(--pc-font-size-md);
        }

        .powercloud-button--large {
            padding: 12px 24px;
            font-size: var(--pc-font-size-lg);
        }

        /* Variants */
        .powercloud-button--primary {
            background-color: var(--pc-primary-color);
            color: white;
        }

        .powercloud-button--primary:hover:not(:disabled) {
            background-color: #0052a3;
        }

        .powercloud-button--secondary {
            background-color: var(--pc-secondary-color);
            color: white;
        }

        .powercloud-button--secondary:hover:not(:disabled) {
            background-color: #5a6268;
        }

        .powercloud-button--success {
            background-color: var(--pc-success-color);
            color: white;
        }

        .powercloud-button--success:hover:not(:disabled) {
            background-color: #218838;
        }

        .powercloud-button--error {
            background-color: var(--pc-error-color);
            color: white;
        }

        .powercloud-button--error:hover:not(:disabled) {
            background-color: #c82333;
        }

        .powercloud-button--warning {
            background-color: var(--pc-warning-color);
            color: var(--pc-dark-color);
        }

        .powercloud-button--warning:hover:not(:disabled) {
            background-color: #e0a800;
        }

        .powercloud-button--adyen {
            background-color: #0abf53;
            color: white;
        }

        .powercloud-button--adyen:hover:not(:disabled) {
            background-color: #089944;
        }

        .powercloud-button--spendcloud {
            background-color: #007aca;
            color: white;
        }

        .powercloud-button--spendcloud:hover:not(:disabled) {
            background-color: #0066b3;
        }

        .powercloud-button--disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        /* Button container styles */
        .powercloud-button-container {
            position: fixed;
            z-index: var(--pc-z-index-extension);
            pointer-events: none;
        }

        .powercloud-buttons-wrapper {
            display: flex;
            gap: var(--pc-spacing-sm);
            pointer-events: auto;
        }

        .powercloud-button-container[data-position*="bottom"] .powercloud-buttons-wrapper {
            flex-direction: column-reverse;
        }

        .powercloud-button-container[data-position*="top"] .powercloud-buttons-wrapper {
            flex-direction: column;
        }

        .powercloud-button-container[data-position*="center"] .powercloud-buttons-wrapper {
            flex-direction: row;
        }
    `}static getAlertStyles(){return`
        .powercloud-alert {
            font-family: var(--pc-font-family);
            border-radius: var(--pc-border-radius);
            box-shadow: var(--pc-shadow-sm);
        }
    `}static getBadgeStyles(){return`
        .powercloud-badge {
            font-family: var(--pc-font-family);
            border-radius: calc(var(--pc-border-radius) * 2);
        }
    `}}class PowerCloudUI{static createButton(t={}){return new PowerCloudButton(t).create()}static createAlert(t={}){return new PowerCloudAlert(t).create()}static createBadge(t={}){return new PowerCloudBadge(t).create()}static createContainer(t={}){return new PowerCloudButtonContainer(t).create(!0)}static getButtonManager(){return window.PowerCloudButtonManagerInstance||(window.PowerCloudButtonManagerInstance=new PowerCloudButtonManager),window.PowerCloudButtonManagerInstance}static initialize(){if(!document.querySelector("#powercloud-ui-styles")){const t=document.createElement("style");t.id="powercloud-ui-styles",t.textContent=PowerCloudUIStyles.getBaseStyles(),document.head.appendChild(t)}}}class PowerCloudButton extends PowerCloudUIComponent{constructor(t={}){super({text:"Button",variant:"primary",size:"medium",disabled:!1,onClick:null,...t})}createElement(){const t=document.createElement("button");return t.className=this.getButtonClasses(),t.textContent=this.options.text,t.disabled=this.options.disabled,t}getButtonClasses(){const t=["powercloud-button"];return t.push(`powercloud-button--${this.options.variant}`),t.push(`powercloud-button--${this.options.size}`),this.options.disabled&&t.push("powercloud-button--disabled"),t.join(" ")}attachEvents(){this.options.onClick&&this.element.addEventListener("click",this.options.onClick)}getCustomStyles(){return`
            .powercloud-button {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
                transition: all 0.2s ease-in-out;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                text-decoration: none;
                position: relative;
                overflow: hidden;
            }

            .powercloud-button:focus {
                outline: 2px solid #0066cc;
                outline-offset: 2px;
            }

            .powercloud-button:active {
                transform: translateY(1px);
            }

            /* Variants */
            .powercloud-button--primary {
                background-color: #0066cc;
                color: white;
            }

            .powercloud-button--primary:hover:not(:disabled) {
                background-color: #0052a3;
            }

            .powercloud-button--secondary {
                background-color: #6c757d;
                color: white;
            }

            .powercloud-button--secondary:hover:not(:disabled) {
                background-color: #5a6268;
            }

            .powercloud-button--success {
                background-color: #28a745;
                color: white;
            }

            .powercloud-button--success:hover:not(:disabled) {
                background-color: #218838;
            }

            .powercloud-button--error {
                background-color: #dc3545;
                color: white;
            }

            .powercloud-button--error:hover:not(:disabled) {
                background-color: #c82333;
            }

            .powercloud-button--warning {
                background-color: #ffc107;
                color: #212529;
            }

            .powercloud-button--warning:hover:not(:disabled) {
                background-color: #e0a800;
            }

            /* Sizes */
            .powercloud-button--small {
                padding: 6px 12px;
                font-size: 12px;
                min-height: 28px;
            }

            .powercloud-button--medium {
                padding: 8px 16px;
                font-size: 14px;
                min-height: 36px;
            }

            .powercloud-button--large {
                padding: 12px 24px;
                font-size: 16px;
                min-height: 44px;
            }

            /* States */
            .powercloud-button--disabled {
                opacity: 0.6;
                cursor: not-allowed;
                pointer-events: none;
            }
        `}}class PowerCloudAlert extends PowerCloudUIComponent{constructor(t={}){super({message:"",type:"info",dismissible:!0,autoHide:!1,hideDelay:5e3,onDismiss:null,...t})}createElement(){const t=document.createElement("div");return t.className=this.getAlertClasses(),t.setAttribute("role","alert"),t.setAttribute("aria-live","polite"),t}setupContent(){const t=this.shadowRoot||this.element,e=document.createElement("div");if(e.className="powercloud-alert__content",e.textContent=this.options.message,this.shadowRoot?this.shadowRoot.appendChild(e):this.element.appendChild(e),this.options.dismissible){const o=document.createElement("button");o.className="powercloud-alert__close",o.innerHTML="&times;",o.setAttribute("aria-label","Close alert"),o.addEventListener("click",()=>this.dismiss()),this.shadowRoot?this.shadowRoot.appendChild(o):this.element.appendChild(o)}this.options.autoHide&&setTimeout(()=>this.dismiss(),this.options.hideDelay)}getAlertClasses(){const t=["powercloud-alert"];return t.push(`powercloud-alert--${this.options.type}`),this.options.dismissible&&t.push("powercloud-alert--dismissible"),t.join(" ")}dismiss(){this.options.onDismiss&&this.options.onDismiss(),this.element.style.opacity="0",setTimeout(()=>this.destroy(),300)}getCustomStyles(){return`
            .powercloud-alert {
                padding: 12px 16px;
                border-radius: 6px;
                margin-bottom: 16px;
                position: relative;
                display: flex;
                align-items: flex-start;
                gap: 8px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                transition: opacity 0.3s ease-in-out;
            }

            .powercloud-alert__content {
                flex: 1;
                font-size: 14px;
                line-height: 1.4;
            }

            .powercloud-alert__close {
                background: none;
                border: none;
                font-size: 18px;
                cursor: pointer;
                color: inherit;
                opacity: 0.7;
                padding: 0;
                width: 20px;
                height: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .powercloud-alert__close:hover {
                opacity: 1;
            }

            .powercloud-alert__close:focus {
                outline: 2px solid currentColor;
                outline-offset: 2px;
            }

            /* Alert types */
            .powercloud-alert--success {
                background-color: #d1edff;
                border: 1px solid #9fdbff;
                color: #0c5aa6;
            }

            .powercloud-alert--error {
                background-color: #ffe6e6;
                border: 1px solid #ffb3b3;
                color: #d63384;
            }

            .powercloud-alert--warning {
                background-color: #fff3cd;
                border: 1px solid #ffe69c;
                color: #856404;
            }

            .powercloud-alert--info {
                background-color: #e7f3ff;
                border: 1px solid #b3d9ff;
                color: #0c5aa6;
            }
        `}}class PowerCloudBadge extends PowerCloudUIComponent{constructor(t={}){super({text:"",variant:"default",size:"medium",...t})}createElement(){const t=document.createElement("span");return t.className=this.getBadgeClasses(),t.textContent=this.options.text,t}getBadgeClasses(){const t=["powercloud-badge"];return t.push(`powercloud-badge--${this.options.variant}`),t.push(`powercloud-badge--${this.options.size}`),t.join(" ")}getCustomStyles(){return`
            .powercloud-badge {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-weight: 500;
                border-radius: 12px;
                white-space: nowrap;
            }

            /* Sizes */
            .powercloud-badge--small {
                padding: 2px 6px;
                font-size: 10px;
                min-height: 16px;
            }

            .powercloud-badge--medium {
                padding: 4px 8px;
                font-size: 12px;
                min-height: 20px;
            }

            .powercloud-badge--large {
                padding: 6px 12px;
                font-size: 14px;
                min-height: 24px;
            }

            /* Variants */
            .powercloud-badge--default {
                background-color: #e9ecef;
                color: #495057;
            }

            .powercloud-badge--primary {
                background-color: #0066cc;
                color: white;
            }

            .powercloud-badge--success {
                background-color: #28a745;
                color: white;
            }

            .powercloud-badge--error {
                background-color: #dc3545;
                color: white;
            }

            .powercloud-badge--warning {
                background-color: #ffc107;
                color: #212529;
            }

            .powercloud-badge--info {
                background-color: #17a2b8;
                color: white;
            }
        `}}class PowerCloudButtonContainer extends PowerCloudUIComponent{constructor(t={}){super({position:"bottom-right",gap:"10px",maxButtons:10,responsive:!0,...t}),this.buttons=new Map,this.container=null,this.wrapper=null}createElement(){const t=document.createElement("div");return t.id="powercloud-button-container",t.className="powercloud-button-container",t}setupContent(){const t=this.shadowRoot||this.element;this.wrapper=document.createElement("div"),this.wrapper.className="powercloud-buttons-wrapper",t.appendChild(this.wrapper),this.updatePosition()}setupShadowContent(){const t=document.createElement("style");t.textContent=this.getComponentStyles(),this.shadowRoot.appendChild(t),this.setupContent()}updatePosition(){if(!this.element)return;const t={"bottom-right":{bottom:"20px",right:"20px",flexDirection:"column-reverse"},"bottom-left":{bottom:"20px",left:"20px",flexDirection:"column-reverse"},"top-right":{top:"20px",right:"20px",flexDirection:"column"},"top-left":{top:"20px",left:"20px",flexDirection:"column"},"bottom-center":{bottom:"20px",left:"50%",transform:"translateX(-50%)",flexDirection:"row-reverse"}},e=t[this.options.position]||t["bottom-right"];this.element.setAttribute("data-position",this.options.position),Object.assign(this.element.style,{position:"fixed",zIndex:"9999",...e}),this.wrapper&&(Object.assign(this.wrapper.style,{display:"flex",flexDirection:e.flexDirection,gap:this.options.gap,alignItems:"stretch"}),this.wrapper.querySelectorAll(".powercloud-button").forEach(n=>{n.style.width="100%",n.style.minWidth="120px"}))}addButton(t){const{id:e,...o}=t;if(this.buttons.has(e))return this.buttons.get(e);const n=new PowerCloudButton({size:"medium",...o}),i=n.create();return i.setAttribute("data-button-id",e),this.wrapper&&(this.wrapper.appendChild(i),i.style.width="100%",i.style.minWidth="120px"),this.buttons.set(e,n),n}removeButton(t){const e=this.buttons.get(t);e&&e.element&&(e.destroy(),this.buttons.delete(t))}clearButtons(){this.buttons.forEach((t,e)=>{this.removeButton(e)})}getButtonCount(){return this.buttons.size}getCustomStyles(){return`
            .powercloud-button-container {
                pointer-events: none;
                font-family: var(--pc-font-family, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif);
            }
            
            .powercloud-buttons-wrapper {
                pointer-events: auto;
            }
            
            .powercloud-buttons-wrapper .powercloud-button {
                pointer-events: auto;
                margin: 0; /* Reset any external margins */
            }
            
            /* Responsive adjustments */
            @media (max-width: 768px) {
                .powercloud-button-container {
                    bottom: 10px !important;
                    right: 10px !important;
                    left: 10px !important;
                }
                
                .powercloud-buttons-wrapper {
                    flex-direction: row !important;
                    flex-wrap: wrap;
                    justify-content: flex-end;
                    gap: 8px !important;
                }
                
                .powercloud-buttons-wrapper .powercloud-button {
                    flex: 0 1 auto;
                    min-width: 120px;
                }
            }
            
            @media (max-width: 480px) {
                .powercloud-buttons-wrapper {
                    flex-direction: column !important;
                    align-items: stretch;
                }
                
                .powercloud-buttons-wrapper .powercloud-button {
                    width: 100%;
                    margin-bottom: 8px;
                }
            }
        `}getComponentStyles(){return PowerCloudUIStyles.getBaseStyles()+PowerCloudUIStyles.getButtonStyles()+`
        /* Visibility control styles */
        .powercloud-visible {
            display: block !important;
        }
        
        .powercloud-hidden {
            display: none !important;
        }
        
        .powercloud-button-container.powercloud-visible {
            display: block !important;
        }
        
        .powercloud-button-container.powercloud-hidden {
            display: none !important;
        }
        `+this.getCustomStyles()}}class PowerCloudButtonManager{constructor(){if(PowerCloudButtonManager.instance)return PowerCloudButtonManager.instance;this.container=null,this.initialized=!1,this.buttons=new Map,this.features=new Set,PowerCloudButtonManager.instance=this}initialize(t={}){if(!this.initialized)try{this.container=new PowerCloudButtonContainer({position:"bottom-right",responsive:!0,...t});const e=this.container.create(!0);document.body.appendChild(e),this.initialized=!0,this.applyVisibilitySettings()}catch{}}applyVisibilitySettings(){if(!(!this.initialized||!this.container||!this.container.element))try{if(window.PowerCloudFeatures&&window.PowerCloudFeatures.uiVisibilityManager){const t=window.PowerCloudFeatures.uiVisibilityManager.showButtons;this.container.element.className=t?"powercloud-button-container powercloud-visible":"powercloud-button-container powercloud-hidden"}else chrome.storage.local.get("showButtons",t=>{const e=t.showButtons===void 0?!0:t.showButtons;this.container.element.className=e?"powercloud-button-container powercloud-visible":"powercloud-button-container powercloud-hidden"})}catch{}}addButton(t,e){this.initialized||this.initialize();const o=`${t}-${e.id||"button"}`;try{if(this.buttons.has(o))return this.buttons.get(o).button;const{id:n,...i}=e,s=this.container.addButton({id:o,...i});return this.buttons.set(o,{feature:t,button:s,config:e}),this.features.add(t),s}catch{return null}}removeButton(t,e=null){if(!(!this.initialized||!this.container))if(e){const o=`${t}-${e}`;this.buttons.has(o)&&(this.container.removeButton(o),this.buttons.delete(o))}else this.removeFeatureButtons(t)}removeFeatureButtons(t){Array.from(this.buttons.keys()).filter(o=>o.startsWith(`${t}-`)).forEach(o=>{this.container.removeButton(o),this.buttons.delete(o)}),this.features.delete(t)}cleanup(){this.container&&(this.container.clearButtons(),this.container.destroy()),this.container=null,this.buttons.clear(),this.features.clear(),this.initialized=!1}getStatus(){return{initialized:this.initialized,buttonCount:this.buttons.size,featureCount:this.features.size,features:Array.from(this.features),buttons:Array.from(this.buttons.keys())}}updateVisibility(t){if(!this.initialized||!this.container||!this.container.element)return!1;try{return this.container.element.className=t?"powercloud-button-container powercloud-visible":"powercloud-button-container powercloud-hidden",!0}catch{return!1}}}typeof module<"u"&&module.exports?module.exports={PowerCloudUIComponent,PowerCloudButton,PowerCloudAlert,PowerCloudBadge,PowerCloudUIStyles,PowerCloudUI,PowerCloudButtonContainer,PowerCloudButtonManager}:typeof window<"u"&&(window.PowerCloudUI=PowerCloudUI,window.PowerCloudUIComponent=PowerCloudUIComponent,window.PowerCloudButton=PowerCloudButton,window.PowerCloudAlert=PowerCloudAlert,window.PowerCloudBadge=PowerCloudBadge,window.PowerCloudUIStyles=PowerCloudUIStyles,window.PowerCloudButtonContainer=PowerCloudButtonContainer,window.PowerCloudButtonManager=PowerCloudButtonManager);
