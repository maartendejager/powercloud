class DebugModeController{constructor(){this.isDebugEnabled=this.checkDebugMode(),this.debugPanel=null,this.startTime=Date.now(),this.logger=window.PowerCloudLoggerFactory?.getLogger("DebugMode")||window.PowerCloudLoggerFactory?.createFallbackLogger("DebugMode"),this.isDebugEnabled&&this.initializeDebugMode()}checkDebugMode(){const e=new URLSearchParams(window.location.search),o=sessionStorage.getItem("powercloud-debug"),t=localStorage.getItem("powercloud-debug");return!!(e.get("powercloud-debug")||o==="true"||t==="true"||window.PowerCloudDebug===!0)}initializeDebugMode(){this.logger.info("Debug mode enabled"),window.PowerCloudDebug=!0,window.PowerCloudLoggerFactory&&(window.PowerCloudLoggerFactory.setGlobalLevel("DEBUG"),window.PowerCloudLoggerFactory.enableDebugMode(!0)),this.addDebugStyles(),this.createDebugPanel(),this.addKeyboardShortcuts(),this.startPerformanceMonitoring(),this.logger.info("Debug mode initialization complete")}addDebugStyles(){const e=`
      #powercloud-debug-panel {
        position: fixed;
        top: 10px;
        right: 10px;
        width: 300px;
        max-height: 400px;
        background: rgba(0, 0, 0, 0.9);
        color: #00ff00;
        font-family: 'Courier New', monospace;
        font-size: 12px;
        border: 1px solid #333;
        border-radius: 5px;
        z-index: 999999;
        overflow: hidden;
        display: none;
      }
      
      #powercloud-debug-panel.visible {
        display: block;
      }
      
      .debug-panel-header {
        background: #333;
        padding: 8px;
        border-bottom: 1px solid #555;
        cursor: move;
        user-select: none;
      }
      
      .debug-panel-content {
        padding: 10px;
        max-height: 350px;
        overflow-y: auto;
      }
      
      .debug-section {
        margin-bottom: 15px;
        border-bottom: 1px solid #333;
        padding-bottom: 10px;
      }
      
      .debug-section h4 {
        margin: 0 0 5px 0;
        color: #ffff00;
      }
      
      .debug-feature-status {
        margin: 2px 0;
      }
      
      .debug-feature-success {
        color: #00ff00;
      }
      
      .debug-feature-failed {
        color: #ff4444;
      }
      
      .debug-toggle-btn {
        position: fixed;
        top: 10px;
        right: 320px;
        background: rgba(0, 0, 0, 0.8);
        color: #00ff00;
        border: 1px solid #333;
        padding: 5px 10px;
        font-size: 12px;
        cursor: pointer;
        z-index: 999998;
        border-radius: 3px;
      }
    `,o=document.createElement("style");o.textContent=e,document.head.appendChild(o)}createDebugPanel(){const e=document.createElement("button");e.id="powercloud-debug-toggle",e.className="debug-toggle-btn",e.textContent="PC Debug",e.onclick=()=>this.toggleDebugPanel(),document.body.appendChild(e);const o=document.createElement("div");o.id="powercloud-debug-panel",o.innerHTML=`
      <div class="debug-panel-header">
        <strong>PowerCloud Debug Panel</strong>
        <span style="float: right; cursor: pointer;" onclick="this.parentElement.parentElement.classList.remove('visible')">\xD7</span>
      </div>
      <div class="debug-panel-content" id="debug-panel-content">
        <div class="debug-section">
          <h4>Loading...</h4>
        </div>
      </div>
    `,document.body.appendChild(o),this.debugPanel=o,this.updateDebugPanel(),setInterval(()=>this.updateDebugPanel(),2e3)}toggleDebugPanel(){this.debugPanel&&this.debugPanel.classList.toggle("visible")}updateDebugPanel(){if(!this.debugPanel)return;const e=document.getElementById("debug-panel-content");if(!e)return;const o=Math.round((Date.now()-this.startTime)/1e3),t=window.location.href,r=window.PowerCloudSafeFeatureManager,a=r?r.getStatusReport():{registered:[],failed:[],stats:{}},d=window.PowerCloudLoggerFactory?window.PowerCloudLoggerFactory.getStats():{};e.innerHTML=`
      <div class="debug-section">
        <h4>System Info</h4>
        <div>Uptime: ${o}s</div>
        <div>URL: ${t}</div>
        <div>Debug: ${this.isDebugEnabled?"ON":"OFF"}</div>
      </div>
      
      <div class="debug-section">
        <h4>Features (${a.registered.length+a.failed.length})</h4>
        ${a.registered.map(n=>`<div class="debug-feature-status debug-feature-success">\u2713 ${n}</div>`).join("")}
        ${a.failed.map(n=>`<div class="debug-feature-status debug-feature-failed">\u2717 ${n}</div>`).join("")}
      </div>
      
      <div class="debug-section">
        <h4>Logger Stats</h4>
        <div>Loggers: ${d.totalLoggers||0}</div>
        <div>Level: ${d.globalLevel||"INFO"}</div>
      </div>
      
      <div class="debug-section">
        <h4>Controls</h4>
        <button onclick="window.PowerCloudDebugController.exportDebugData()" style="margin: 2px; padding: 2px 6px; font-size: 11px;">Export Data</button>
        <button onclick="window.PowerCloudDebugController.clearLogs()" style="margin: 2px; padding: 2px 6px; font-size: 11px;">Clear Logs</button>
      </div>
    `}addKeyboardShortcuts(){document.addEventListener("keydown",e=>{e.ctrlKey&&e.shiftKey&&e.code==="KeyD"&&(e.preventDefault(),this.toggleDebugPanel()),e.ctrlKey&&e.shiftKey&&e.code==="KeyL"&&(e.preventDefault(),this.exportDebugData())})}startPerformanceMonitoring(){let e=Date.now();const o=()=>{const t=Date.now(),r=t-e;r>5e3&&this.logger.warn(`Long gap detected: ${r}ms`),e=t,setTimeout(o,1e3)};o()}exportDebugData(){const e={timestamp:new Date().toISOString(),url:window.location.href,uptime:Date.now()-this.startTime,features:window.PowerCloudSafeFeatureManager?window.PowerCloudSafeFeatureManager.getStatusReport():{},loggerStats:window.PowerCloudLoggerFactory?window.PowerCloudLoggerFactory.getStats():{},failedFeatures:JSON.parse(sessionStorage.getItem("powercloud-failed-features")||"[]"),userAgent:navigator.userAgent,performance:{memory:performance.memory?{usedJSHeapSize:performance.memory.usedJSHeapSize,totalJSHeapSize:performance.memory.totalJSHeapSize}:null}},o=JSON.stringify(e,null,2),t=new Blob([o],{type:"application/json"}),r=URL.createObjectURL(t),a=document.createElement("a");a.href=r,a.download=`powercloud-debug-${Date.now()}.json`,a.click(),URL.revokeObjectURL(r),this.logger.info("Debug data exported")}clearLogs(){sessionStorage.removeItem("powercloud-failed-features"),window.PowerCloudLoggerFactory&&typeof window.PowerCloudLoggerFactory.clearLogs=="function"&&window.PowerCloudLoggerFactory.clearLogs(),this.logger.info("Logs cleared")}static enableDebugMode(){sessionStorage.setItem("powercloud-debug","true"),window.location.reload()}static disableDebugMode(){sessionStorage.removeItem("powercloud-debug"),localStorage.removeItem("powercloud-debug"),window.location.reload()}}window.PowerCloudDebugController=new DebugModeController;
